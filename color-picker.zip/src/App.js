import { Header } from "./components/Header";
import { Main } from "./components/Main";
import { Star } from "./components/Star";
import { UseState } from "./components/UseState";
import { SecExam } from "./components/SecExam";
import { ThirdExam } from "./components/ThirdExam";
import { FourExam } from "./components/FourExam";
import "./App.css";

function App() {
  return (
    <div className="App flex items-center justify-center h-screen w-screen">
      {/* <Header /> */}
      {/* <Main /> */}
      {/* <Star /> */}
      <UseState />
      <SecExam />
      <ThirdExam />
      <FourExam />
    </div>
  );
}

export default App;
