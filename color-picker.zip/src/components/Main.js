import { useState } from "react";

export const Main = () => {
  const [color, setColor] = useState("#FFFFFF");

  return (
    <div className="flex items-center justify-center h-screen ">
      <div
        className="h-2/4 w-2/4 bg-slate-700"
        style={{ backgroundColor: color }}
      >
        <input
          className="flex justify-center items-center cursor-pointer w-full"
          type="color"
          value={color}
          onChange={(e) => setColor(e.target.value)}
        ></input>
      </div>
    </div>
  );
};
