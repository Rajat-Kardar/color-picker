import { useState } from "react";

export const FourExam = () => {
  //   const defaultValue = () => {
  //     (name: john
  //         age:42)
  //   };
  const [name, setName] = useState("John");
  const handleName = (event) => {
    setName(event.target.value);
  };
  const [age, setAge] = useState(42);
  const handleAge = () => {
    setAge(age + 1);
  };
  return (
    <div className="items-center justify-center w-72 h-72 bg-slate-400 m-8 p-12 rounded-lg">
      <input
        className="bg-green-300 rounded-md items-center text-center text-blue-600"
        type="text"
        placeholder="Write Name"
        onChange={handleName}
      ></input>
      <button
        className="cursor-pointer w-44 bg-blue-700 rounded-xl mt-4 h-8"
        onClick={handleAge}
      >
        Increment Age
      </button>
      <p className="text-white font-serif font-bold mt-4 shadow-sm">
        Hello {name}, Your age is {age}.
      </p>
    </div>
  );
};
