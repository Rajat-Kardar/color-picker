import { useState } from "react";

export const ThirdExam = () => {
  const [check, setcheck] = useState(true);
  const handleCheck = (event) => {
    setcheck(event.target.checked);
  };
  return (
    <div className="h-48 w-48 m-8 p-4 bg-slate-700 rounded-md">
      <input type="checkbox" checked={check} onChange={handleCheck}></input>
      <p>I like this.</p>
      <p>You {check ? "liked" : "not liked"} this.</p>
    </div>
  );
};
