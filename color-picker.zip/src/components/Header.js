import React from "react";

export const Header = () => {
  return (
    <div className="bg-gray-700 h-20 max-w-full p-6">
      <p className="text-center text-red-400 font-extrabold text-3xl">
        ColorPicker
      </p>
    </div>
  );
};
