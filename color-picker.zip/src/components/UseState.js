import { useState } from "react";

export const UseState = () => {
  const [count, setcount] = useState(0);

  const inputChange = (event) => {
    setcount(event.target.value);
  };

  function handleCounter() {
    setcount(count + 1);
  }
  return (
    <div className="m-8">
      {/* <input
        id=""
        className="text-center border-green-200 bg-cyan-100 text-blue-700 h-10 border-8 rounded-lg p-2"
        type="number"
        placeholder="Enter Number"
        onChange={inputChange}
      ></input> */}
      <button
        className="bg-gray-700 border-4 border-black text-center cursor-pointer text-white rounded-md p-4 "
        onClick={handleCounter}
      >
        You pressed {count}times.
      </button>
    </div>
  );
};
