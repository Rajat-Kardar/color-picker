import { useState } from "react";

export const SecExam = () => {
  const [text, setText] = useState("Hello");

  const handleInputValue = (event) => {
    setText(event.target.value);
  };

  return (
    <div className=" h-60 w-72 bg-slate-700 m-8 p-8 rounded-md">
      <input
        className="text-center text-white
         bg-blue-700 font-bold rounded-md"
        type="input"
        placeholder="Hello"
        value={text}
        onChange={handleInputValue}
      ></input>
      <p className="text-white font-serif font-medium text-2xl shadow-md p-4">
        You Type :{text}
      </p>
      <button
        className="bg-green-700 w-52 h-12 rounded-full mt-4"
        onClick={() => setText("Hello")}
      >
        Reset
      </button>
    </div>
  );
};
