import { useState } from "react";

export const Star = () => {
  const [star, setStar] = useState(5);

  return (
    <div className="flex flex-col items-center justify-center h-screen">
      <h2 className="font-medium ">Star Tree</h2>
    </div>
  );
};
